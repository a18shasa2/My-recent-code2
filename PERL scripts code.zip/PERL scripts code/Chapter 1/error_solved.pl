#!/usr/bin/perl -w
print("This program will have a syntax error\n");