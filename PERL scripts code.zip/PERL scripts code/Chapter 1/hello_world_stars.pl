#!/usr/bin/perl �w 
print("****************\n* Hello World! *\n**************** \n"); 
#Just copy and paste text within quotation marks, and add \n at the correct places. 