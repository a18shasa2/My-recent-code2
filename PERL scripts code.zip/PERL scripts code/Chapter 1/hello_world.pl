#!/usr/bin/perl �w 
print("Hello World!\n"); 