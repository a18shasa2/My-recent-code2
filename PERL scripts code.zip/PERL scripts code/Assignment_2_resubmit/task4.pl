#!/usr/bin/perl
@symbols = ("V", "L", "M");


$full1 = scalar(@symbols);
$zero = 0;


@sequences = ("MVRLARTL", "LVGAMV");
$full2 = scalar(@sequences);

#A loop is used to compare the presence of all variables in the array with the amino acids. 
while($zero < $full1){
$V=@symbols[$zero];
$null = 0;
#A loop is used to compare the presence of the designated amino acid in all variables in the array with the sequences. 
while($null < $full2){
$sequence1=@sequences[$null];

@sequence1_split = split("", $sequence1);
@sequence_1_V = ();
my @sequence_1_V;

#If the amino acid is present in the sequence, it will be added to the designated array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@sequence1_split){
if ($nucleotide eq $V){
push(@sequence_1_V,$V);
}
}
@sequence_1_V_total = ();
my @sequence_1_V_total;

@sequence_1_V_total=join("", @sequence_1_V);
$sequence_1_V_join=@sequence_1_V_total[0];
$sequence_1_V_counted=length($sequence_1_V_join);

print "$symbols[$zero] found $sequence_1_V_counted times in $sequence1\n";
undef @sequence1_split;
undef @sequence_1_V;
undef @sequence_1_V_total;
$null++;
}
undef @sequence1_split;
undef @sequence_1_V;
undef @sequence_1_V_total;
$zero++;
}
