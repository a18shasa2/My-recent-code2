#!/usr/bin/perl
$ARGV[0];

sub smallFunction{
@array1 = ();
my @array1;
push(@array1, $input1);
$input1_initial_length = length($input1);
$part_split1=@array1[0];
@part_split1_1 = split("", $part_split1);
@array1_G = ();
my @array1_G;
@array1_C = ();
my @array1_C;
#If the nucleotide is present in the sequence, it will be added to the array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@part_split1_1){
if ($nucleotide eq "T"){
push(@array1_G,"T");
}
elsif ($nucleotide eq "C"){
push(@array1_C,"C");
}
}
@array1_G_join = ();
my @array1_G_join;
@array1_G_join=join("", @array1_G);
$array1_G_total=@array1_G_join[0];
$array1_G_total_counted=length($array1_G_total);
@array1_C_join = ();
my @array1_C_join;
@array1_C_join=join("", @array1_C);
$array1_C_total=@array1_C_join[0];
$array1_C_total_counted=length($array1_C_total);
$array1_GC_percentage = (($array1_G_total_counted+$array1_C_total_counted)/$input1_initial_length)*100;


print "Seq$num2: $input1, $input1_initial_length nt, $array1_GC_percentage% pyrimidines\n";

} 

$num1=$ARGV[0];
$num2=1;
$num3=0;
while ($num3 < $num1) {
print "Type seq$num2: ";
$input1 = <STDIN>;
chomp($input1);
#A subroutine is defined and performs the analysis of the pyrimidines. 
smallFunction(); 
$num3++;
$num2++;
}