#!/usr/bin/perl
print "Enter the sequence: ";
$input1 = <STDIN>;
chomp($input1);
$seq_length_total = length($input1);
@amino_acid = ("A", "R", "N", "D", "C", "Q", "E", "G", "H", "I", "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V");
@array = ();
my @array;
push(@array, $input1);
$part_split=@array[0];
@part_split1 = split("", $part_split);
@array1 = ();
my @array1;
#If the amino acid is present in the sequence, it will be added to the array and counted. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@part_split1){
if ($nucleotide eq "A"){
push(@array1,"A");
}
elsif ($nucleotide eq "R"){
push(@array2,"R");
}
elsif ($nucleotide eq "N"){
push(@array3,"N");
}
elsif ($nucleotide eq "D"){
push(@array4,"D");
}
elsif ($nucleotide eq "C"){
push(@array5,"C");
}
elsif ($nucleotide eq "Q"){
push(@array6,"Q");
}
elsif ($nucleotide eq "E"){
push(@array7,"E");
}
elsif ($nucleotide eq "G"){
push(@array8,"G");
}
elsif ($nucleotide eq "H"){
push(@array9,"H");
}
elsif ($nucleotide eq "I"){
push(@array10,"I");
}
elsif ($nucleotide eq "L"){
push(@array11,"L");
}
elsif ($nucleotide eq "K"){
push(@array12,"K");
}
elsif ($nucleotide eq "M"){
push(@array13,"M");
}
elsif ($nucleotide eq "F"){
push(@array14,"F");
}
elsif ($nucleotide eq "P"){
push(@array15,"P");
}
elsif ($nucleotide eq "S"){
push(@array16,"S");
}
elsif ($nucleotide eq "T"){
push(@array17,"T");
}
elsif ($nucleotide eq "W"){
push(@array18,"W");
}
elsif ($nucleotide eq "Y"){
push(@array19,"Y");
}
elsif ($nucleotide eq "V"){
push(@array20,"V");
}
}
$array1_count = scalar(@array1);
push(@count1, $array1_count);
$array2_count = scalar(@array2);
push(@count1, $array2_count);
$array3_count = scalar(@array3);
push(@count1, $array3_count);
$array4_count = scalar(@array4);
push(@count1, $array4_count);
$array5_count = scalar(@array5);
push(@count1, $array5_count);
$array6_count = scalar(@array6);
push(@count1, $array6_count);
$array7_count = scalar(@array7);
push(@count1, $array7_count);
$array8_count = scalar(@array8);
push(@count1, $array8_count);
$array9_count = scalar(@array9);
push(@count1, $array9_count);
$array10_count = scalar(@array10);
push(@count1, $array10_count);
$array11_count = scalar(@array11);
push(@count1, $array11_count);
$array12_count = scalar(@array12);
push(@count1, $array12_count);
$array13_count = scalar(@array13);
push(@count1, $array13_count);
$array14_count = scalar(@array14);
push(@count1, $array14_count);
$array15_count = scalar(@array15);
push(@count1, $array15_count);
$array16_count = scalar(@array16);
push(@count1, $array16_count);
$array17_count = scalar(@array17);
push(@count1, $array17_count);
$array18_count = scalar(@array18);
push(@count1, $array18_count);
$array19_count = scalar(@array19);
push(@count1, $array19_count);
$array20_count = scalar(@array20);
push(@count1, $array20_count);

#In a loop, the total number of each type of amino acid is compared with each other. If the next value is equal to the present value, no change will occur. If the next value is higher than the present value, a change will occur and that value will be kept. If the next value is lower than the present value, no change will occur. When the highest value has been compared to all other values, the program will proceed linearly and use the highest value of that amino acid. 
$t1=0;
$tc1=0;
while ($t1 < 20){
if ($count1[$tc1] == $count1[$t1]){
$tc1=$tc1;
}
elsif ($count1[$tc1] > $count1[$t1]){
$tc1=$tc1;
}
elsif ($count1[$tc1] < $count1[$t1]){
$tc1=$t1;
}
$t1++;
}
print "The most common amino acid: $amino_acid[$tc1]\n";
print "Number of occurrences: $count1[$tc1]\n";
$percent = ($count1[$tc1] / $seq_length_total) * 100;
print "Frequency: $percent% ($count1[$tc1] out of $seq_length_total)\n";
