#!/usr/bin/perl

#The coloumns "Entry name" and "Length" were selected. 
#The entry names "COBQ_HALHL" and "COXX_RICB8" and "AGAL_SCHPO" were selected. 
print "What is the Entry name?: ";
$input1 = <STDIN>;
chomp($input1);
$loopVar = $input1;
%hash = ("COBQ_HALHL" => "483","COXX_RICB8" => "300","AGAL_SCHPO" => "436");
$values = values(%hash);
#If the selected entry names are NOT inputted, the line "Not found, try again" will appear repeatedly until the selected entry names are inputted and then the program will function linearly again and print the desired value in the hash. 
$zero = 0;
$one = 1;
while($zero < $one){

if($loopVar eq "COBQ_HALHL"){
print "Length of the protein is ";
print("$hash{'COBQ_HALHL'}\n");
$zero++;
}

elsif($loopVar eq "COXX_RICB8"){
print "Length of the protein is ";
print("$hash{'COXX_RICB8'}\n");
$zero++;
}

elsif($loopVar eq "AGAL_SCHPO"){
print "Length of the protein is ";
print("$hash{'AGAL_SCHPO'}\n");
$zero++;
}

else{
print "Not found, try again\n";
print "What is the Entry name?: ";
$input1 = <STDIN>;
chomp($input1);
$loopVar = $input1;
$zero++;
$one++;
}

}

