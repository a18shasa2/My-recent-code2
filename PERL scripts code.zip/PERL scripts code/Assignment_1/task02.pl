#First input. Second concentation.  
print("Enter the repeated sequence:"); 
$input1 = <STDIN>;
chomp($input1);
$part1 = $input1;
$part2 = $input1;
$part3 = $input1;
$string = $part1 . $part2 . $part3;
print "The concatenated sequence is: $string.";