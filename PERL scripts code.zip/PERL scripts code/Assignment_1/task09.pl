#First arguments. Second input. Third substr mutation switch. Fourth print.
print "Enter the accession number:";
$input1 = <STDIN>;
chomp($input1);
print "Enter the name of the protein:";
$input2 = <STDIN>;
chomp($input2);
print "Enter the name of the species:";
$input3 = <STDIN>;
chomp($input3);
print "Enter the length (number of amino acids):";
$input4 = <STDIN>;
chomp($input4);
%hash = ("AccessionNr" => "$input1","EntryName" => "$input2","Species" => "$input3","Length" => "$input4");
$values = values(%hash);
print "You have entered the following values:\n";
print("$hash{'AccessionNr'} $hash{'EntryName'} $hash{'Species'} $hash{'Length'}");