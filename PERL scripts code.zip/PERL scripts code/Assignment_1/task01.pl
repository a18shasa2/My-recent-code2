print"Please enter a gene name:"; 
$input1 = <STDIN>;
chomp($input1);
print"Please enter a species name:"; 
$input2 = <STDIN>;
chomp($input2);
print "You entered gene name $input1 and species $input2\n";
#The data type of the two variables is strings and the data structure is scalar.