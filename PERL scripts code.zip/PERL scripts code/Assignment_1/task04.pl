#First input. Second arrow. Third print arrays. 
print "Enter the index of the gene to print:";
$input1 = <STDIN>;
chomp($input1);
@gene = ("Gene1", "Gene2", "Gene3","Gene4","Gene5");
print "That is gene is called $gene[$input1]\n";
shift(@gene);
print "The array now contains: @gene\n"