use strict;
use warnings;
#First arguments. Second input. Third substr mutation switch. Fourth print.
my $name   = $ARGV[5];
my $number = $ARGV[3];
$number_G = 5 
my $name   = $ARGV[$number_G];
#$number = 4;
#$name = G;
print "Give me the sequence $number:";
$input1 = <STDIN>;
chomp($input1);
substr($input1, 4, 8, "G");
print "The mutated sequence sequence: $input1";