#First input. Second arrow. Third print arrays. 
print "Enter gene 1:";
$input1 = <STDIN>;
chomp($input1);
print "Enter gene 2:";
$input2 = <STDIN>;
chomp($input2);
print "Enter gene 3:";
$input3 = <STDIN>;
chomp($input3);
@gene = ($input1, $input2, $input3);
@gene_sorted = sort(@gene);
print "Your genes are: @gene_sorted\n";