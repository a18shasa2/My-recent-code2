#First arguments. Second input. Third substr mutation switch. Fourth print.
print "Give me the sequence:";
$input1 = <STDIN>;
chomp($input1);
$input1_total = length($input1);
$triplet1 = substr($input1, 0, 3);
$triplet2 = substr($input1, 3, 3);
$triplet1_length = length($triplet1);
$triplet2_length = length($triplet2);
$result = $input1_total-($triplet1_length+$triplet2_length);
print "Triplets: $triplet1 $triplet2";
print "\nRemaining characters: $result";