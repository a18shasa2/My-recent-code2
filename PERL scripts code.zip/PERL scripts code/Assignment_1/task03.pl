#First input. Second concentation.  
print "Enter the sequence:";
$input1 = <STDIN>;
chomp($input1);
print "Enter the segment length:";
$input2 = <STDIN>;
chomp($input2);
print "Enter the segment start position:";
$input3 = <STDIN>;
chomp($input3);
$input1_capital_first_three = substr($input1, $input3, $input2);
print "$input1_capital_first_three";