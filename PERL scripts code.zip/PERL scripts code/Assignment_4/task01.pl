#!/usr/bin/perl

#A file handle is created and lines of disease.txt are counted. 
open(TEXTFILE1, "<diseases.txt");

#For the rough outline, see the file "rough outline task01.PNG". Preferably read in full-screen or maximized window. 
#For the pseudocode, see the file "pseudocode task01.pdf"
#One example of a module is "use warnings"
#Below is an example of referencing
$nr_of_lines = 0;
$total0=\$nr_of_lines;
while (<TEXTFILE1>) { 
	$nr_of_lines++;
}
close TEXTFILE1;

#User-input for the disease code is indicated. 
print("Type the disease code: ");
$input1 = <STDIN>;
chomp($input1);

#A file handle is created and lines are read and each line is stored into an array. 
open(TEXTFILE, "<diseases.txt");
$add1=0;
while ($add1 < $nr_of_lines){
	$line = <TEXTFILE>;
	push(@array2, $line);
	@array2_splitted = split(";", $array2[0]);
	push(@array1, $line);
	@array1_splitted = split(";", $array1[0]);

#If the first element of the array equals the user-inputted variable, the specimen´s name is printed. If not, the program will check each line of the txt-file until they match. 
if ($array1_splitted[0] eq $input1){
shift(@array1_splitted);
pop(@array1_splitted);
pop(@array1_splitted);
print "@array1_splitted \n";

#User-input for the text-file is indicated. 
print("Type the name of the sequence file: ");
$input2 = <STDIN>;
chomp($input2);
#The lines of the user-inputted text-file are read. 
open(TEXTFILE2, "<$input2");
$nr_of_lines1 = 0;
while (<TEXTFILE2>) { 
	$nr_of_lines1++;
}
close TEXTFILE2;

open(TEXTFILE3, "<$input2");
$add2=0;
while ($add2 < $nr_of_lines1){
$line1 = <TEXTFILE3>;
	push(@array4, $line1);
	push(@array9, $line1);
$add2++;
}
shift(@array4);
@array4_join=join("", @array4);
@array4_join_split=split("", $array4[0]);
$seq=$array4_join[0];
$seq_length=length($seq);

$add3=0;
$var1=0;
#If a repeat of CAG is present, the number of times CAG appears in the repeat is counted. The highest counted number of repeats is printed. 
while ($add3 < $seq_length){
$B02=$add3+1;
$B03=$add3+2;
$CAG2_check = $array4_join_split[$add3] . $array4_join_split[$B02] . $array4_join_split[$B03];
if ($CAG2_check eq "CAG"){
push(@array5, "A");
$add3++;
$add3++;
$add3++;
}
elsif ($CAG2_check ne "CAG"){
$count1=scalar(@array5);
if ($count1 > $var1){
$var1=$count1;
}
elsif ($count1 < $var1){
}
elsif ($count1 = $var1){
}
undef @array5;
$add3++;
}
}
print "Repeat length: $var1 \n";

#If the highest counted number of repeats of CAG in ATNA1.txt is equal to or higher than the value in disease.txt, ”pathogenic” will be printed. If not, ”normal” will be printed. 
$grand=scalar(@array2_splitted);
$grand1=$grand-1;
$disease=$array2_splitted[$grand1];
if ($var1 == $disease){
print "Pathogenic";
}
elsif ($var1 > $disease){
print "Pathogenic";
}
elsif ($var1 < $disease){
print "Normal";
}



}

elsif ($array1_splitted[0] ne $input1){
}

undef @array1;
undef @array1_splitted;
undef @array2;
undef @array2_splitted;
undef @array4;
undef @array4_join;
undef @array4_join_split;
$add1++;
}
close TEXTFILE;
close TEXTFILE3;