#!/usr/bin/perl

#For the sake of clarity, after each printed line, one line is skipped, so it will be easier to read the lines. You may need to scroll up and down in the command-prompt.
#A file handle is created and lines of the fasta-file are counted. 
$ARGV[0];

open(TEXTFILE1, "<sequencesTrembl.fasta");
$nr_of_lines = 0;
while (<TEXTFILE1>) { 
	$nr_of_lines++;
}
close TEXTFILE1;

open(TEXTFILE3, "<sequencesTrembl.fasta");
@ref=<TEXTFILE3>;
close TEXTFILE3;

#The number of accession numbers are counted.
$A01=0;
$accession_count=0;
while ($A01 < $nr_of_lines){
if($ref[$A01] =~ />/){
$nr_of_lines1=$nr_of_lines+1;
$accession_count++;
}
$A01++;
}



#A file handle is created. and lines are read. As long as a line with the symbol ">" is NOT read, except the first line, each line will be read and stored into an array. 
open(TEXTFILE, "<sequencesTrembl.fasta");
$add1=0;
$count1_STRK=0;
$count11_STRK=0;
$count2_STDE=0;
$count22_STDE=0;
$count3_RKRKST=0;
$count33_RKRKST=0;
while ($add1 < $accession_count){

$A00=0;
push(@array2, $ref[$A00]);
shift(@ref);
while ($A00 < $nr_of_lines){
if($ref[0] =~ />/){
$nr_of_lines1=$nr_of_lines+1;
while($A00 < $nr_of_lines1){
$A00++;
}
}
elsif($ref[0] !=~ />/){
push(@A1, $ref[0]);
shift(@ref);
@A1_split=split("", $A1[0]);
pop(@A1_split);
@A1_split_join = join("", @A1_split);
push(@line_single, $A1_split_join[0]);
undef @A1;
undef @A1_split;
undef @A1_split_join;
}
$A00++;
}
@line_single_join=join("", @line_single);
push(@array2, $line_single_join[0]);
undef @line_single;
undef @line_single_join;

push(@accession, $array2[0]);
push(@accession_store, $array2[0]);
push(@sequence, $array2[1]);
@accession_split=split("", $accession[0]);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
shift(@accession_split);
pop(@accession_split);
@accession_join=join("", @accession_split);
push(@protein_name, $accession_join[0]);
#The number of proteins that contain the respective pattern is counted. 
if($array2[1] =~ /[ST].[RK]/){
$count1_STRK++;
}
if($array2[1] =~ /[ST]..[DE]/){
$count2_STDE++;
}
if($array2[1] =~ /[RK][RK].[ST]/){
$count3_RKRKST++;
}

#The total number of times that each pattern appear in each sequence is counted and the protein with the highest amount is printed. 
$length=length($array2[1]);
@length_split=split("", $array2[1]);
$B01=0;
while ($B01 < $length){
$B02=$B01+1;
$B03=$B01+2;
$B04=$B01+3;
$codon_check = $length_split[$B01] . $length_split[$B02] . $length_split[$B03] . $length_split[$B04];
if($codon_check =~ /[ST].[RK]/){
push(@seq1, "A");
$count11_STRK++;
}
elsif($codon_check !=~ /[ST].[RK]/){
}

if($codon_check =~ /[ST]..[DE]/){
push(@seq2, "A");
$count22_STDE++;
}
elsif($codon_check !=~ /[ST]..[DE]/){
}

if($codon_check =~ /[RK][RK].[ST]/){
push(@seq3, "A");
$count33_RKRKST++;
}
elsif($codon_check !=~ /[RK][RK].[ST]/){
}

$B01++;
}

$pattern1=scalar(@seq1);
push(@pattern_count1, $pattern1);
$pattern2=scalar(@seq2);
push(@pattern_count2, $pattern2);
$pattern3=scalar(@seq3);
push(@pattern_count3, $pattern3);

undef @array2;
undef @accession;
undef @accession_split;
undef @accession_join;
undef @length_split;
undef @seq1;
undef @seq2;
undef @seq3;
$add1++;

}
close TEXTFILE;
print "$count1_STRK proteins contain at least one occurrence of Protein kinase C phosphorylation site\n\n";
print "$count2_STDE proteins contain at least one occurrence of Casein kinase II phosphorylation site\n\n";
print "$count3_RKRKST proteins contain at least one occurrence of cAMP- and cGMP-dependent protein kinase phosphorylation site\n\n";
$t1=0;
$tc1=0;
$total1=scalar(@pattern_count1);
while ($t1 < $total1){
if ($pattern_count1[$tc1] == $pattern_count1[$t1]){
$tc1=$tc1;
}
elsif ($pattern_count1[$tc1] > $pattern_count1[$t1]){
$tc1=$tc1;
}
elsif ($pattern_count1[$tc1] < $pattern_count1[$t1]){
$tc1=$t1;
}
$t1++;
}
print "$protein_name[$tc1] has the highest number of Protein kinase C phosphorylation site\n\n";

$t2=0;
$tc2=0;
$total2=scalar(@pattern_count2);
while ($t2 < $total2){
if ($pattern_count2[$tc2] == $pattern_count2[$t2]){
$tc2=$tc2;
}
elsif ($pattern_count2[$tc2] > $pattern_count2[$t2]){
$tc2=$tc2;
}
elsif ($pattern_count2[$tc2] < $pattern_count2[$t2]){
$tc2=$t2;
}
$t2++;
}
print "$protein_name[$tc2] has the highest number of Casein kinase II phosphorylation site\n\n";

$t3=0;
$tc3=0;
$total3=scalar(@pattern_count3);
while ($t3 < $total3){
if ($pattern_count3[$tc3] == $pattern_count3[$t3]){
$tc3=$tc3;
}
elsif ($pattern_count3[$tc3] > $pattern_count3[$t3]){
$tc3=$tc3;
}
elsif ($pattern_count3[$tc3] < $pattern_count3[$t3]){
$tc3=$t3;
}
$t3++;
}
print "$protein_name[$tc3] has the highest number of cAMP- and cGMP-dependent protein kinase phosphorylation site\n\n";
#If an argument is entered and if the accession number in the argument is present in the fasta-file, the start and end-position of every site of protein kinase C phosphyrlation patterns in the corresponding sequence are printed. 

if ($ARGV[0] eq ""){
$zero=$total1;
}
while ($zero < $total1){
if($accession_store[$zero] =~ /$ARGV[0]/){
$length1=length($sequence[$zero]);
@length_split1=split("", $sequence[$zero]);
$B011=0;
while ($B011 < $length1){
$B021=$B011+1;
$B031=$B011+2;
$arg_check = $length_split1[$B011] . $length_split1[$B021] . $length_split1[$B031];
if($arg_check =~ /[ST].[RK]/){
print "The site $arg_check has the start-position $B011 and end-position $B031\n\n";
}
$B011++;
}

}
$zero++;
}
#Below is an example of a 2D-array. 
@multiarray = (\@protein_name, \@sequence, \@accession_store);