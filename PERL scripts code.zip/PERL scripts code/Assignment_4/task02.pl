#!/usr/bin/perl

#Note: It may take some time for the program to finish its analysis. For the sake of clarity, the program will print "The program has finished. See the file sequencesTrembl.fasta." when the program has finished. 
#A file handle is created and lines of accNr.txt are counted. 
open(FILE1, "<accNr.txt");
$nr = 0;
while (<FILE1>) { 
	$nr++;
}
close FILE1;

#A file handle is created and lines are read and each accession number is stored into an array. 
open(FILE, "<accNr.txt");
$go1=0;
while ($go1 < $nr){
	$lin = <FILE>;
	push(@array2, $lin);
	@array2_splitted = split(" ", $array2[0]);
	push(@accession_number, $array2_splitted[0]);
undef @array2;
undef @array2_splitted;
undef @array2_splitted_join;
$go1++;
}
close FILE;

$accession_total=scalar(@accession_number);
$origin = 0;
while ($origin < $accession_total) { 
#The file handle is opened and the total number of lines in the text-file is counted.
open(TEXTFILE1, "<genbank.txt");
$nr_of_lines = 0;
while (<TEXTFILE1>) { 
	$nr_of_lines++;
}
close TEXTFILE1;
$one=0;
#A new file handle is opened and lines are read. 
open(TEXTFILE, "<genbank.txt");
$add1=0;
$add2=0;
$add11=0;
$count1=0;
while ($add1 < $nr_of_lines){
	$line = <TEXTFILE>;
	push(@array2, $line);
$val1=0;
#A regular expression is used to detect the element in the array that has the accession number and on which line it lies on. 
@array21=split(" ", $array2[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /$accession_number[$origin]/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$count2=$add1;
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
undef @array21;
$add1++;	
}
#The file handle is closed.
close TEXTFILE;


#A new file handle is opened and lines are read in order to start at the beginning.
open(TEXTFILE2, "<genbank.txt");
#All lines until the line with the designated accession number and its database are skipped.
$skip=0;
$count10 = $count2 - 15;
$count9 = $count2 + 1;
while ($skip < $count10){
<TEXTFILE2>;
$skip++;
}
$skip2=0;
$count3=0;
$final=$nr_of_lines-$count2-3;
#The name of the protein-product corresponding to the accession number is read and stored into an array. 
while ($count10 < $count9){
	$line2 = <TEXTFILE2>;
	push(@array31, $line2);
	@array31_splitted = split(" ", $array31[0]);

foreach $array31 (@array31){
	if($array31 =~ /product/){
push(@array4, $array31);
@array4_split=split("", $array4[0]);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
pop(@array4_split);
pop(@array4_split);
@array4_split_join = join("", @array4_split);
while ($one < 1){
push(@protein_name, $array4_split_join[0]);
$one++;
}
	}
}
$count10++;
}
undef @array31;
undef @array31_splitted;
undef @array4;
undef @array4_split;
undef @array4_split_join;

#The sequence corresponding to the accession number is read and stored into an array.  
$count14 = $count2 + 14;
while ($count9 < $nr_of_lines){
	$line3 = <TEXTFILE2>;
	push(@array31, $line3);
	@array31_splitted = split(" ", $array31[0]);
if ($array31_splitted[0] eq "gene"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] eq "CDS"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] eq "source"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] eq "polyA_site"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] eq "STS"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] eq "exon"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] eq "ORIGIN"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
elsif ($array31_splitted[0] ne "misc_feature"){
push(@sequence, $array31_splitted[$skip2]);
$count9++;
}

elsif ($array31_splitted[0] eq "misc_feature"){
$count141=$nr_of_lines+1;
while ($count9 < $count141) {
$count9++;
}
}
undef @array31;
undef @array31_splitted;
undef @array31_splitted_join;
undef @array31_splitted_join_split;
$skips2++;
}

@sequence_join = join("", @sequence);
@sequence_join_split = split("", $sequence_join[0]);
pop(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
shift(@sequence_join_split);
@sequence_join_split_join = join("", @sequence_join_split);
push(@sequence_full, $sequence_join_split_join[0]);
undef @sequence;
undef @sequence_join;
undef @sequence_join_split;
undef @sequence_join_split_join;
$origin++;
}
#The file handle is closed.
close TEXTFILE2;

for (@sequence_full) 
{
s/\"ORIGIN\///g;
}

#For each accession number, the corresponding protein-product name and sequence is also written onto the file sequencesTrembl.fasta. 
$origin1=0;
$var132=0;
while ($var132 < $accession_total){
if ($var132 == 0) {
open (WRITE, ">sequencesTrembl.fasta");
}
elsif ($var132 > 0) {
open (WRITE, ">>sequencesTrembl.fasta");
}
print (WRITE ">$accession_number[$origin1], $protein_name[$origin1]\n");
$sequence_full_count=length($sequence_full[$origin1]);
@sequence_full_split=split("", $sequence_full[$origin1]);
$zer=0;
while($zer < $sequence_full_count){
$ze=0;
while($ze < 76){
push(@char, $sequence_full_split[$ze]);
$ze++;
$zer++;
}
$z=0;
while($z < 76){
shift(@sequence_full_split);
$z++;
}
@char_join=join("", @char);
push(@lines_fasta, $char_join[0]);
undef @char_join;
undef @char;
$zer++;
}
$lines_fasta_count=scalar(@lines_fasta)-1; 
$LB1=$lines_fasta_count+1;
$LB0=0;
while ($LB0 < $LB1){
print (WRITE "$lines_fasta[$LB0]\n");
$LB0++;
}
undef @lines_fasta;
undef @sequence_full_split;
close WRITE;
$origin1++;
$var132++;
}
print "The program has finished. See the file sequencesTrembl.fasta";
