#!/usr/bin/perl
$ARGV[0];
#Note: When reading the comments, use the side-bar.
#A filehandle is associated with a txt-file and opened using the open-function and the input-operators "<...>" are used to read all lines of the txt-file. Once the line is read, the line is returned as a string. The string is stored into an array. All lines are stored into an array. The total number of elements in the array are determined using the scalar-function. The filehandle is then disassociated using the close-function.
open(TEXTFILE1, "<$ARGV[0]");
@array_archive = <TEXTFILE1>;
@array_archive_full = join(" ", @array_archive);
$nr_of_lines = scalar(@array_archive);
close TEXTFILE1;

@array1=();
my @array1;
@array2=();
my @array2;
@array21=();
my @array21;
@array3=();
my @array3;

$add1=0;
$add2=0;
$add11=0;
$val11=0;
$count1=0;
$val1=0;
$val2=0;
$val3=0;
while ($add1 < $nr_of_lines){
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "SQ" and the pattern is searched for in the string "$array21". If the string matches the pattern, the second and third element of the array are stored into another array.
@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /SQ/){
push(@array3, @array21);
push(@name, $array3[2]);
$look = $add1;
@array3_split=split("", $array3[3]);
pop(@array3_split);
@array3_split_join = join("", @array3_split);
push(@name, $array3_split_join[0]);
$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;

undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "AC" and the pattern is searched for in the string "$array21". If the string matches the pattern, all characters of the second element of the array, except the last character, are pushed into another array.
@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /AC/){
@array3_split=split("", $array21[1]);
pop(@array3_split);
@array3_split_join = join("", @array3_split);
push(@accre, $array3_split_join[0]);
$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;

undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
undef @array21;
$add1++;	
}

$minus = $nr_of_lines - 1; 
while ($look < $minus){
@array21=split(" ", $array_archive[$look]);
$sequence_sum = $array21[0] . $array21[1] . $array21[2] . $array21[3] . $array21[4] . $array21[5];
push(@sequence_full, $sequence_sum);
undef @array21;
$look++;
}
shift(@sequence_full);
$seq_to=scalar(@sequence_full);

$zero1=0;

#A file handle is associated to a fasta-file and the string to write are given as arguments. A print-function is used to write a string to a file. If a fasta-file with the same name is present during the first writing, its content is overwritten as indicated by the sign ">". If not, a new file will be created and the writing will be performed on that file. During the second writing and beyond, the writing starts at the end of the previous writing as indicated by the sign ">>". 
open (WRITE, ">$accre[0].fasta");
print (WRITE "> $accre[0], @name\n");
open (WRITE1, ">>$accre[0].fasta");
while ($zero1 < $seq_to){
print (WRITE1 "$sequence_full[$zero1]\n");
$zero1++;
}
print "Sequence printed in Fasta format to file $accre[0].fasta\n";