#!/usr/bin/perl
$ARGV[0];
$num1=$ARGV[0];
$num2=1;
$num3=0;
while ($num3 < $num1) {
print "Type the file name for sequence $num2: ";
$input1 = <STDIN>;
chomp($input1);
#If the filehandle can be associated with the txt-file, the analysis will occur. If not, an error message stating "Genbank file..." will appear and the session will be terminated.
if(open(TEXTFILE, "$input1")){ 
#Note: When reading the comments, use the side-bar.
#A filehandle is associated with a txt-file using the open-function and the input-operators "<...>" are used to read all lines of the txt-file. Once the line is read, the line is returned as a string. The string is stored into an array. All lines are stored into an array. The total number of elements in the array are determined using the scalar-function. The filehandle is then disassociated using the close-function.
open(TEXTFILE1, "<$input1");
@array_archive = <TEXTFILE1>;
$nr_of_lines = scalar(@array_archive);
close TEXTFILE1;

@array1=();
my @array1;
@array2=();
my @array2;
@array21=();
my @array21;
@array3=();
my @array3;

$add1=0;
$add2=0;
$add11=0;
$val11=0;
$count1=0;
$val1=0;
while ($add1 < $nr_of_lines){
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "AC" and the pattern is searched for in the string "$array21". If the string matches the pattern, the element beside or next to or to the right of "AC" in the array is printed.  

@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /AC/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
@array39_split=split("", $array21[$add4]);
pop(@array39_split);
@array39_split_join = join("", @array39_split);

while ($val11 < 1){
print "Accession number: @array39_split_join\n";
$val11++;
}
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "OS" and the pattern is searched for in the string "$array21". If the string matches the pattern, the entire line except the first 3 characters are printed.  
@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /OS/){
push(@array3, @array21);
shift(@array3);
@array3_split=split("", $array3[0]);
@array3_split_join = join("", @array3_split);
while ($val1 < 1){
print "Source organism: @array3 \n";
$val1++;
}
$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;

undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
undef @array21;
$add1++;	
}


#The database references are counted below and the number is printed. Each time "DR" is present, one value will be added. If not, a value will not be added.
$skip2=0;
$count3=0;
while ($skip2 < $nr_of_lines){
	@array31_splitted = split(" ", $array_archive[$skip2]);
if ($array31_splitted[0] eq "DR"){
$count3++;
$skip2++;
undef @array31_splitted;
undef @array31;
}
elsif ($array31_splitted[0] ne "DR"){
$skip2++;
undef @array31_splitted;
undef @array31;
}
}
print "$count3 database references\n";
}
elsif(!open(TEXTFILE, "$input1")){
	die "UniProt file not found. Terminating..\n";
}
$num3++;
$num2++;
}
