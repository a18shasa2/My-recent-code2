#!/usr/bin/perl

#Note: When reading the comments, use the side-bar.
#A filehandle is associated with a txt-file and the txt-file opened using the open-function along with the sign "<" and the input-operators "<...>" are used to read all lines of the txt-file. Once the line is read, the line is returned as a string. The string is stored into an array. All lines are stored into an array. The total number of elements in the array are determined using the scalar-function. The filehandle is then disassociated using the close-function.
open(FILE1, "<entryNames.txt");
@accession = <FILE1>;
$nr = scalar(@accession);
close FILE1;

#The entry names are stored into an array.  
$go1=0;
while ($go1 < $nr){
	push(@acc, $accession[$go1]);
	@acc_splitted = split(" ", $acc[0]);
	push(@accession_number, $acc_splitted[0]);
undef @acc;
undef @acc_splitted;
undef @acc_splitted_join;
$go1++;
}

print "$nr entries found in entryNames.txt \n";

#A filehandle is associated with a txt-file using the open-function and the input-operators "<...>" are used to read all lines of the txt-file. Once the line is read, the line is returned as a string. The string is stored into an array. All lines are stored into an array. The total number of elements in the array are determined using the scalar-function. The filehandle is then disassociated using the close-function.
$origin = 0;
while ($origin < $nr) {
open(TEXTFILE1, "<$accession_number[$origin].txt");
@array_archive = <TEXTFILE1>;
$nr_of_lines = scalar(@array_archive);
close TEXTFILE1;

@array1=();
my @array1;
@array2=();
my @array2;
@array21=();
my @array21;
@array3=();
my @array3;

$add1=0;
$add2=0;
$add11=0;
$val11=0;
$count1=0;
$val1=0;
while ($add1 < $nr_of_lines){
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "RX" and the pattern is searched for in the string "$array21". If the string matches the pattern, all characters of the second element in the array, except the first 7 characters and the last character, is stored into another array.  
@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /RX/){
push(@array3, @array21);
shift(@array3);
@array3_split=split("", $array3[0]);
pop(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);
push(@reference_number, $array3_split_join[0]);
$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;

undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
undef @array21;
$add1++;	
}
$origin++;
}

$ref_count = scalar(@reference_number);

#A file handle is associated to a txt-file and the string to write are given as arguments. A print-function is used to write a string to a file. If a txt-file with the same name is present during the first writing, its content is overwritten as indicated by the sign ">". If not, a new file will be created and the writing will be performed on that file. During the second writing and beyond, the writing starts at the end of the previous writing as indicated by the sign ">>". 
$var132=0;
while ($var132 < $ref_count){
if ($var132 == 0) {
open (WRITE, ">bibliography.txt");
}
elsif ($var132 > 0) {
open (WRITE, ">>bibliography.txt");
}
print (WRITE "$reference_number[$var132]\n");
$var132++;
}
print "$ref_count PubMed reference numbers written to bibliography.txt \n";