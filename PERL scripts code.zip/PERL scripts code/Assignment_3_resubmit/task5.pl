#!/usr/bin/perl
$ARGV[0];
#Note: When reading the comments, use the side-bar.
#A filehandle is associated with a txt-file using the open-function and the input-operators "<...>" are used to read all lines of the txt-file. Once the line is read, the line is returned as a string. The string is stored into an array. All lines are stored into an array. The total number of elements in the array are determined using the scalar-function. The filehandle is then disassociated using the close-function.
open(TEXTFILE1, "<$ARGV[0].txt");
@array_archive = <TEXTFILE1>;
@array_archive_full = join(" ", @array_archive);
$nr_of_lines = scalar(@array_archive);
close TEXTFILE1;

@array1=();
my @array1;
@array2=();
my @array2;
@array21=();
my @array21;
@array3=();
my @array3;

$add1=0;
$add2=0;
$add11=0;
$val11=0;
$count1=0;
$val1=0;
$val2=0;
$val3=0;
while ($add1 < $nr_of_lines){
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "SQ" and the pattern is searched for in the string "$array21". If the string matches the pattern, the length will be compared. If the length is below 100 or greater than 999, a "no..." will appear. If not, a "yes..." will appear.
@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /SQ/){
push(@array3, @array21);
shift(@array3);
shift(@array3);
@array3_split=split("", $array3[0]);
@array3_split_join = join("", @array3_split);
while ($val1 < 1){
if ($array3_split_join[0] > 99){
if ($array3_split_join[0] < 1000 ){
print "Yes, the sequence length between 100 and 999\n";
}
elsif ($array3_split_join[0] > 1000){
print "No, the sequence length is not between 100 and 999\n";
}
}
elsif ($array3_split_join[0] < 100){
print "No, the sequence length is not between 100 and 999\n";
}
$val1++;
}
$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;

undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "primates" and the pattern is searched for in the string "$array_archive_full". If the string matches the pattern, the type of group will be checked. If it belongs to "primates", a "yes..." will appear. If not, a "no..." will appear.  
foreach $array_archive_full (@array_archive_full){
while ($val3 < 1){
	if($array_archive_full =~ /Primates/){
print "Yes is primate\n";
	}
	elsif($array_archive_full !=~ /Primates/){
print "No, is not primate\n";
	}
$val3++;
}
}
#A regular expression is used. The operation called matching is used and the pattern is written within the forward slashes, which causes only that exact pattern to be matched and no variations. The characters that are defined for the desired pattern within the forward slashes is "DT" and the pattern is searched for in the string "$array21". If the string matches the pattern, the decade will be checked. If the first three characters of the year equals "199", a "yes..." will appear. If not, a "no..." will appear.  
@array21=split(" ", $array_archive[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /DT/){
push(@array3, @array21);
shift(@array3);
@array3_split=split("", $array3[0]);
pop(@array3_split);
pop(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);
while ($val2 < 1){
if ($array3_split_join[0] == 199){
print "Yes, integrated into UniProt in the 1990s\n";
}
elsif ($array3_split_join[0] != 199){
print "No, not integrated into UniProt in the 1990s\n";
}
$val2++;
}
$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;

undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
undef @array21;
$add1++;	
}

