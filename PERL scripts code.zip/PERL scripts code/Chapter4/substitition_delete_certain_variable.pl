for (@fileContents) 
{
s/\"ORIGIN\/\//""/g;
}
