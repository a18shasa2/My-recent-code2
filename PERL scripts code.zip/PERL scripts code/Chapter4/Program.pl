#!/usr/bin/perl
open(TEXTFILE, "<text.txt");
@array3=();
while (<TEXTFILE>){
	$line2 = <TEXTFILE>;
	push(@array3, $line2);
	@array3_splitted = split(" ", $array3[0]);
if ($array3_splitted[0] eq "LOCUS"){
print "This word is $array3_splitted[2]";
undef @array3_splitted;
undef @array3;
}
elsif ($array3_splitted[0] ne "LOCUS"){
undef @array3_splitted;
undef @array3;
}
}
close TEXTFILE;
