#!/usr/bin/perl

use warnings;

open(MY_HANDLE, "<line.txt");
$fileLine = <MY_HANDLE>;
print($fileLine);
close(MY_HANDLE);
