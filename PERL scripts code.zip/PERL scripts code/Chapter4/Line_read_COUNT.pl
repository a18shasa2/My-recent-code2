open(TEXTFILE, "<LOCUSNM_converted.txt");

$first_line = <TEXTFILE>;

@first_word = split(" ", $first_line);

print("$first_word[0]\n");

$exon_count = 0;
#Counts the number of exons in the file
#DO I have to includew "This textfile is opened"
#Do you use Cygwin or Command-prompt to run programs? Is Terminal easier than Command-prompt? 

#How do you read a textfile with "<textfile.txt" in Terminal? I have always have to specify the path in the code. 
#How do you do that in terminal? cd So it´s the same as in command-prompt. 



#If the first element is "exon", it will be counted.  Is it enough, or does it have to be more detailed?
#Why will you chanage ot Python? But it doesn´t matter really if you take Perl or Python. 
while (<TEXTFILE>){
	$first_line = <TEXTFILE>;
	
	@first_word = split(" ", $first_line);
	print($first_word[0], "\n");
	if ($first_word[0] eq "exon"){
	 
	my @first_word;
		$exon_count++;
	}
}

print("Total number of exons: $exon_count\n");