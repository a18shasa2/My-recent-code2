#!/usr/bin/perl
open(TEXTFILE, "<NM_000071.txt");

$add2=0;
while ($add2 < 4){
<TEXTFILE>;
$add2++;
}
$add1=0;
while ($add1 < 1){
	$line = <TEXTFILE>;
	push(@array1, $line);
	@array1_splitted = split(" ", $array1[0]);
	shift(@array1_splitted);
$add1++;	
}

$add3=0;
while ($add3 < 1){
<TEXTFILE>;
$add3++;
}
$add4=0;
while ($add4 < 1){
	$line1 = <TEXTFILE>;
	push(@array2, $line1);
	@array2_splitted = split(" ", $array2[0]);
	shift(@array2_splitted);
$add4++;	
}

$add5=0;
while ($add5 < 125){
<TEXTFILE>;
$add5++;
}
$add6=0;
$count1=0;
while ($add6 < 184){
	$line2 = <TEXTFILE>;
	push(@array3, $line2);
	@array3_splitted = split(" ", $array3[0]);
if ($array3_splitted[0] eq "exon"){
$count1++;
$add6++;
undef @array3_splitted;
undef @array3;
}
elsif ($array3_splitted[0] ne "exon"){
$add6++;
undef @array3_splitted;
undef @array3;
}
}
print "Version number: $array1_splitted[0]\n";
print "Source organism: @array2_splitted\n";
print "$count1 exons\n";
close TEXTFILE;
