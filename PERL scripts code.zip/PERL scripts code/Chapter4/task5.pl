#!/usr/bin/perl
$ARGV[0];
@array1=();
my @array1;
@array2=();
my @array2;
$input2=$ARGV[0];
$input1=$ARGV[0];
$var3=0;
@input1_split = split("", $input1);
$total=scalar(@input1_split);
while ($var3 < $total) {
if ($input1_split[$var3] eq "A"){
}
elsif ($input1_split[$var3] eq "a"){
}
elsif ($input1_split[$var3] eq "C"){
}
elsif ($input1_split[$var3] eq "c"){
}
elsif ($input1_split[$var3] eq "G"){
}
elsif ($input1_split[$var3] eq "g"){
}
elsif ($input1_split[$var3] eq "t"){
}
elsif ($input1_split[$var3] eq "T"){
}
else {
die "This sequence contains wrong characters\n";
}
$var3++;
}

$num_start_1=0;
$num_start_2=1;
$num_start_3=2;
$num_end_1=$total-3;
$num_end_2=$total-2;
$num_end_3=$total-1;
$part1_start = $input1_split[$num_start_1];
$part2_start = $input1_split[$num_start_2];
$part3_start = $input1_split[$num_start_3];
$codon_start= $part1_start . $part2_start . $part3_start;
$part1_end = $input1_split[$num_end_1];
$part2_end = $input1_split[$num_end_2];
$part3_end = $input1_split[$num_end_3];
$codon_end = $part1_end . $part2_end . $part3_end;
if ($codon_start eq "ATG"){
print "Begins with start codon\n";
}
if ($codon_end eq "TAG"){
print "Begins with end codon\n";
}
$num1=3;
$num2=0;
$num3=$num2*$num1;
while ($num3 < $total)  {
$triplet1 = substr($input2, $num3, 3);
if ($triplet1 eq "ATG"){
push(@array1,"E");
}
$num2++;
}
$count1=scalar(@array1);
print "Contains $count1 start codons\n";
$num2_1=0;
$num3_1=$num2_1*$num1;
while ($num3_1 < $total)  {
$triplet1 = substr($input2, $num3_1, 3);
if ($triplet1 eq "ATG"){
}
elsif ($triplet1 eq "TAG"){
}
else {
push(@array2,$triplet1);
}
$num2_1++;
}
print "Contains ORF: @array2\n";