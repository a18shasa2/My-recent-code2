use strict;
use warnings;


my @ary = ("test", 5, "third");
my @ary = ("test", 5, "third");
print @ary[0];