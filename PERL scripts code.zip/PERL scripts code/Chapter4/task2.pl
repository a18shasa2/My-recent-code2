#!/usr/bin/perl
$ARGV[0];
$num1=$ARGV[0];
$num2=1;
$num3=0;
while ($num3 < $num1) {
print "Type the accession number of sequence $num2: ";
$input1 = <STDIN>;
chomp($input1);
if(open(TEXTFILE, "$input1.txt")){ 
#The file handle is created and opened. 
open(TEXTFILE, "<$input1.txt");
#Four lines are skipped
$add2=0;
while ($add2 < 4){
<TEXTFILE>;
$add2++;
}
#The version number is determined. One line is read, stored in an array, splitted in the array and the first element of the array is removed. The loop then continues linearly since the cycle is broken.
$add1=0;
while ($add1 < 1){
	$line = <TEXTFILE>;
	push(@array1, $line);
	@array1_splitted = split(" ", $array1[0]);
	shift(@array1_splitted);
$add1++;	
}
#One line is skipped.
$add3=0;
while ($add3 < 1){
<TEXTFILE>;
$add3++;
}
#The source name is determined. One line is read, stored in an array, splitter in the array and the first element of the array is removed. The loop then continues linearly since the cycle is broken.
$add4=0;
while ($add4 < 1){
	$line1 = <TEXTFILE>;
	push(@array2, $line1);
	@array2_splitted = split(" ", $array2[0]);
	shift(@array2_splitted);
$add4++;	
}

$add5=0;
while ($add5 < 125){
<TEXTFILE>;
$add5++;
}
$add6=0;
$count1=0;
#The exons are counted below. If the first element in array3 is an exon, an element will be added to the array4. If not, an element will NOT be added to the array4. The cycle repeats until 184 lines have been read and then the program continues linearly.  
while ($add6 < 184){
	$line2 = <TEXTFILE>;
	push(@array3, $line2);
	@array3_splitted = split(" ", $array3[0]);
if ($array3_splitted[0] eq "exon"){
$count1++;
$add6++;
undef @array3_splitted;
undef @array3;
}
elsif ($array3_splitted[0] ne "exon"){
$add6++;
undef @array3_splitted;
undef @array3;
}
}
print "Version number: $array1_splitted[0]\n";
print "Source organism: @array2_splitted\n";
print "$count1 exons\n";
close TEXTFILE;
$num2++;
}
elsif(!open(TEXTFILE, "$input1.txt")){
die "Genbank file not found. Terminating..";
}
}
