#!/usr/bin/perl

open(TEXTFILE, "<NM_000071.txt");

$add2=0;
while ($add2 < 4){
<TEXTFILE>;
$add2++;
}
$add1=0;
while ($add1 < 1){
	$line = <TEXTFILE>;
	push(@array1, $line);
	@array1_splitted = split(" ", $array1[0]);
	shift(@array1_splitted);
	#clear array
	#print ($array1_splitted[0], "\n");
$add1++;	
}

$add3=0;
while ($add3 < 1){
<TEXTFILE>;
$add3++;
}
$add4=0;
while ($add4 < 1){
	$line1 = <TEXTFILE>;
	push(@array2, $line1);
	@array2_splitted = split(" ", $array2[0]);
	shift(@array2_splitted);
	#clear array
	#print ($array2_splitted[0], "\n");
$add4++;	
}

$add5=0;
while ($add5 < 125){
<TEXTFILE>;
$add5++;
}
$add6=0;
$count1=0;
while ($add6 < 184){
	$line2 = <TEXTFILE>;
	push(@array3, $line2);
	@array3_splitted = split(" ", $array3[0]);
if ($array3_splitted[0] eq "exon"){
$count1++;
$add6++;
undef @array3_splitted;
undef @array3;
}
elsif ($array3_splitted[0] ne "exon"){
$add6++;
undef @array3_splitted;
undef @array3;
}
}
print "Version number: $array1_splitted[0]\n";
print "Source organism: @array2_splitted\n";
print "$count1 exons\n";
#if ($array1_splitted[0] eq "NM_000071.2"){
#print "This word was successfully identified";
#}

close TEXTFILE;
#print "@array1";
#if (!open(TEXTFILE, "<line.txt")){
#die "Did not read line.txt";
#}
#$line = <TEXTFILE>; READ ONE LINE
#@ARRAY1 = <TEXTFILE>; READ ALL LINES 
#Each element is ONE line in array. After split, each element is ONE word if use SPACE. 
#How do you split using space
		  #Each space BEFORE the word, becomes one element
 #COMMAND PROMPT: cd Downloads/perl/Chapter4 (enter) perl line_read.pl)
 
 #My mistakes was <.txt AND < > for skipping AND " " AND directory then use COMMAND-PROMPT
 
 #If lines are NOT in allignment in mac-created txt-file, convert to normal text file using Word. 
 
 #Can you use a regular expression to delete all ATG? Answer: substitute: s/ATG/""/g
 #DELTETE SUBSTITION IF VAR NEED /: = s/ \"ORIGIN\/\/ /""/g
 
 #If use PROGRAM in THESIS, refer to code to link from GITHUB.