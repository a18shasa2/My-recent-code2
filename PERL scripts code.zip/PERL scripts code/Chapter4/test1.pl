open(TEXTFILE1, "<B7NR61.txt");
@array_archive = <TEXTFILE1>;
$nr_of_lines = scalar(@array_archive);
print "COUNTED $nr_of_lines LINES $array_archive[0]";
close TEXTFILE1;