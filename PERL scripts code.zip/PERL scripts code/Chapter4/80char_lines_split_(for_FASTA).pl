#gives lines with 80char for FASTA
#Now only need a way to store and pritn them. 
#Note @sequence_full is name of array with FIRST FULL line. 
$sequence_full_count=scalar(@sequence_full);
$zer=0;
while($zer < $sequence_full_count){
@sequence_full_split=split("", $sequence_full[$zer]);
$ze=0;
while($ze < 80){
push(@char, $sequence_full_split[$ze]);
$ze++;
}
@char_join=join("", @char);
push(@lines_fasta, $char_join[0]);
undef @char_join;
undef @char;
undef @sequence_full_split;
$zer++;
}
$lines_fasta_count=scalar(@lines_fasta);
#Second part of code (inside WRITE_hhandle):
$LB=0;
while ($LB < $lines_fasta_count){
print (WRITE1 ">$lines_fasta[$LB]\n");
$LB++;
}
(write handle - must be manual)

(OUTSIDE writehandle)
undef @lines_fasta
#one way could be to write to file for all content in @lines_fasta and THEN undef @lines_fasta

