#!/usr/bin/perl

#The coloumns "Entry name" and "Length" were selected. 
#The entry names "COBQ_HALHL" and "COXX_RICB8" and "AGAL_SCHPO" were selected. 
print "What is the Entry name?: ";
$input1 = <STDIN>;
chomp($input1);
$loopVar = $input1;
#If the selected entry names are NOT inputted, the line "Not found, try again" will appear repeatedly until the selected entry names are inputted and then the program will function linearly again. 
while($loopVar ne "COBQ_HALHL"){
print "Not found, try again\n";
print "What is the Entry name?: ";
$input1 = <STDIN>;
chomp($input1);
$loopVar = $input1;
}
%hash = ("COBQ_HALHL" => "483","COXX_RICB8" => "300","AGAL_SCHPO" => "436");
$values = values(%hash);
print "Length of the protein is ";
print("$hash{'COBQ_HALHL'}");