#!/usr/bin/perl
@symbols = ("V", "L", "M");
$V=@symbols[0];
$L=@symbols[1];
$M=@symbols[2];
@sequences = ("MVRLARTL", "LVGAMV");
$sequence1=@sequences[0];
$sequence2=@sequences[1];

@sequence1_split = split("", $sequence1);
@sequence_1_V = ();
my @sequence_1_V;
@sequence_1_L = ();
my @sequence_1_L;
@sequence_1_M = ();
my @sequence_1_M;
#If the amino acid is present in the sequence, it will be added to the designated array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@sequence1_split){
if ($nucleotide eq $V){
push(@sequence_1_V,$V);
}
elsif ($nucleotide eq $L){
push(@sequence_1_L,$L);
}
elsif ($nucleotide eq $M){
push(@sequence_1_M,$M);
}
}
@sequence_1_V_total = ();
my @sequence_1_V_total;
@sequence_1_L_total = ();
my @sequence_1_L_total;
@sequence_1_M_total = ();
my @sequence_1_M_total;
@sequence_1_V_total=join("", @sequence_1_V);
$sequence_1_V_join=@sequence_1_V_total[0];
$sequence_1_V_counted=length($sequence_1_V_join);
@sequence_1_L_total=join("", @sequence_1_L);
$sequence_1_L_join=@sequence_1_L_total[0];
$sequence_1_L_counted=length($sequence_1_L_join);
@sequence_1_M_total=join("", @sequence_1_M);
$sequence_1_M_join=@sequence_1_M_total[0];
$sequence_1_M_counted=length($sequence_1_M_join);

@sequence2_split = split("", $sequence2);
@sequence_2_V = ();
my @sequence_2_V;
@sequence_2_L = ();
my @sequence_2_L;
@sequence_2_M = ();
my @sequence_2_M;
#If the amino acid is present in the sequence, it will be added to the designated array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide1 (@sequence2_split){
if ($nucleotide1 eq $V){
push(@sequence_2_V,$V);
}
elsif ($nucleotide1 eq $L){
push(@sequence_2_L,$L);
}
elsif ($nucleotide1 eq $M){
push(@sequence_2_M,$M);
}
}
@sequence_2_V_total = ();
my @sequence_2_V_total;
@sequence_2_L_total = ();
my @sequence_2_L_total;
@sequence_2_M_total = ();
my @sequence_2_M_total;
@sequence_2_V_total=join("", @sequence_2_V);
$sequence_2_V_join=@sequence_2_V_total[0];
$sequence_2_V_counted=length($sequence_2_V_join);
@sequence_2_L_total=join("", @sequence_2_L);
$sequence_2_L_join=@sequence_2_L_total[0];
$sequence_2_L_counted=length($sequence_2_L_join);
@sequence_2_M_total=join("", @sequence_2_M);
$sequence_2_M_join=@sequence_2_M_total[0];
$sequence_2_M_counted=length($sequence_2_M_join);

print "V found $sequence_1_V_counted times in $sequence1\n";
print "V found $sequence_2_V_counted times in $sequence2\n";
print "L found $sequence_1_L_counted times in $sequence1\n";
print "L found $sequence_2_L_counted times in $sequence2\n";
print "M found $sequence_1_M_counted times in $sequence1\n";
print "M found $sequence_2_M_counted times in $sequence2\n";


