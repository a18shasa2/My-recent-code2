#!/usr/bin/perl
print "Enter a DNA sequence: ";
$input1 = <STDIN>;
chomp($input1);
push(@array, $input1);
print "More sequences? (yes/no)\n";
$input2 = <STDIN>;
chomp($input2);
$loopVar = $input2;
#If "yes" is inputted, the lines "Enter a DNA sequence" and "More sequences" will appear repeatedly as long as "yes" is inputted in $input2. If non-yes, such as "no", is inputted, the loop will be broken and the program will continue linearly. 
while($loopVar eq "yes"){
	print "Enter a DNA sequence: ";
$input1 = <STDIN>;
chomp($input1);
push(@array, $input1);
print "More sequences? (yes/no)\n";
$input2 = <STDIN>;
chomp($input2);
$loopVar = $input2;
}
print "@array\n";
print "Which sequence do you want to see in reverse?\n";
$input3 = <STDIN>;
chomp($input3);
$part_reverse=@array[$input3];
@part_reverse1 = split("", $part_reverse);
@part_reverse2=reverse(@part_reverse1);
@part_reverse3=join("", @part_reverse2);
print "$part_reverse3[0]\n";