#!/usr/bin/perl
print "Type seq1: ";
$input1 = <STDIN>;
chomp($input1);
print "Type seq2: ";
$input2 = <STDIN>;
chomp($input2);
print "Type seq3: ";
$input3 = <STDIN>;
chomp($input3);

@array1 = ();
my @array1;
push(@array1, $input1);
$input1_initial_length = length($input1);
$part_split1=@array1[0];
@part_split1_1 = split("", $part_split1);
@array1_G = ();
my @array1_G;
@array1_C = ();
my @array1_C;
#If the nucleotide is present in the sequence, it will be added to the array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@part_split1_1){
if ($nucleotide eq "G"){
push(@array1_G,"G");
}
elsif ($nucleotide eq "C"){
push(@array1_C,"C");
}
}
@array1_G_join = ();
my @array1_G_join;
@array1_G_join=join("", @array1_G);
$array1_G_total=@array1_G_join[0];
$array1_G_total_counted=length($array1_G_total);
@array1_C_join = ();
my @array1_C_join;
@array1_C_join=join("", @array1_C);
$array1_C_total=@array1_C_join[0];
$array1_C_total_counted=length($array1_C_total);
$array1_GC_percentage = (($array1_G_total_counted+$array1_C_total_counted)/$input1_initial_length)*100;

@array2 = ();
my @array2;
push(@array2, $input2);
$input2_initial_length = length($input2);
$part_split2=@array2[0];
@part_split2_2 = split("", $part_split2);
@array2_G = ();
my @array2_G;
@array2_C = ();
my @array2_C;
#If the nucleotide is present in the sequence, it will be added to the array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@part_split2_2){
if ($nucleotide eq "G"){
push(@array2_G,"G");
}
elsif ($nucleotide eq "C"){
push(@array2_C,"C");
}
}
@array2_G_join = ();
my @array2_G_join;
@array2_G_join=join("", @array2_G);
$array2_G_total=@array2_G_join[0];
$array2_G_total_counted=length($array2_G_total);
@array2_C_join = ();
my @array2_C_join;
@array2_C_join=join("", @array2_C);
$array2_C_total=@array2_C_join[0];
$array2_C_total_counted=length($array2_C_total);
$array2_GC_percentage = (($array2_G_total_counted+$array2_C_total_counted)/$input2_initial_length)*100;

@array3 = ();
my @array3;
push(@array3, $input3);
$input3_initial_length = length($input3);
$part_split3=@array3[0];
@part_split3_3 = split("", $part_split3);
@array3_G = ();
my @array3_G;
@array3_C = ();
my @array3_C;
#If the nucleotide is present in the sequence, it will be added to the array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@part_split3_3){
if ($nucleotide eq "G"){
push(@array3_G,"G");
}
elsif ($nucleotide eq "C"){
push(@array3_C,"C");
}
}
@array3_G_join = ();
my @array3_G_join;
@array3_G_join=join("", @array3_G);
$array3_G_total=@array3_G_join[0];
$array3_G_total_counted=length($array3_G_total);
@array3_C_join = ();
my @array3_C_join;
@array3_C_join=join("", @array3_C);
$array3_C_total=@array3_C_join[0];
$array3_C_total_counted=length($array3_C_total);
$array3_GC_percentage = (($array3_G_total_counted+$array3_C_total_counted)/$input3_initial_length)*100;

print "Seq1: $input1, $input1_initial_length nt, $array1_GC_percentage% GC\n";
print "Seq2: $input2, $input2_initial_length nt, $array2_GC_percentage% GC\n";
print "Seq3: $input3, $input3_initial_length nt, $array3_GC_percentage% GC\n";

my $input1_1   = $ARGV[0]