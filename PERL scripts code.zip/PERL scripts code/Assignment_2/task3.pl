#!/usr/bin/perl
print "Enter the sequence: ";
$input1 = <STDIN>;
chomp($input1);
@array = ();
my @array;
push(@array, $input1);
$part_split=@array[0];
@part_split1 = split("", $part_split);
@array1 = ();
my @array1;
#If the amino acid is present in the sequence, it will be added to the array. If not, the program will move on to the next amino acid and add that to the array if it is present. When all conditions are false, the program will continue to flow linearly. 
foreach $nucleotide (@part_split1){
if ($nucleotide eq "V"){
push(@array1,"V");
}
elsif ($nucleotide eq "I"){
push(@array1,"I");
}
elsif ($nucleotide eq "L"){
push(@array1,"L");
}
elsif ($nucleotide eq "F"){
push(@array1,"F");
}
elsif ($nucleotide eq "W"){
push(@array1,"W");
}
elsif ($nucleotide eq "Y"){
push(@array1,"Y");
}
elsif ($nucleotide eq "M"){
push(@array1,"M");
}
}
@array2 = ();
my @array2;
@array2=join("", @array1);
$part_join=@array2[0];
$total_counted=length($part_join);
print "There are $total_counted hydrophobic residues in that sequence\n";
