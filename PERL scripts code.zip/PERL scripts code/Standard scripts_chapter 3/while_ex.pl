#!/usr/bin/perl -w

$loopVar = 1;
while($loopVar < 3){
	print "Iteration $loopVar\n";
	$loopVar++;
}
