#!/usr/bin/perl -w

@DNA = ("ACCA", "TAAGCCG", "", "GTTAGA", "AC");
foreach $sequence (@DNA){
	if(length($sequence) < 5){
		next;
	}
	print("Sequence: $sequence\n");
}
