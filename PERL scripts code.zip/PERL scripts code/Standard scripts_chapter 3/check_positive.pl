#!/usr/bin/perl

use warnings;
use strict;

sub checkPositive{
	my $number = $_[0];
	if($number > 0){
		return 1;
	}
	else{
		return 0;
	}
}

my $value = -5;
if(checkPositive($value)){
	print "$value is positive.\n";
}
else{
	print "$value is zero or less.\n";
}
