#!usr/bin/perl -w

print("Welcome to the Miniature command prompt!\n");
print("Please enter a command and press Enter.\n\n");
print(">");

$command = <STDIN>;
chomp($command);

if($command eq "help"){
	print("Available commands are: 'help' 'os' and 'quit'\n");
}
elsif($command eq "os"){
	print("Perl is running in $^O\n");
}
elsif($command eq "quit"){
	exit;
}
else{
	print("Invalid command\n");
}
