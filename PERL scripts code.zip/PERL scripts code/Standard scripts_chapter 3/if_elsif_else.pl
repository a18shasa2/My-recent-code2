#!/usr/bin/perl -w

$scalarVar = 5;
if($scalarVar < 4){
	print "$scalarVar is less than 4.";
}
elsif($scalarVar > 6){
	print "$scalarVar is greater than 6.";
}
else{
	print "$scalarVar is a number between 4 and 6.";
}
