#!/usr/bin/perl -w

$scalarVar = 5;
if($scalarVar < 10){
	print "$scalarVar is less than 10.\n";
}
if($scalarVar > 3){
	print "$scalarVar is greater than 3.\n";
}
if($scalarVar == 6){
	print "$scalarVar is equal to 6.\n";
}
