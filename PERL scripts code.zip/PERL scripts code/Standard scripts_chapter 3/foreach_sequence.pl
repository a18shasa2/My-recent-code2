#!usr/bin/perl -w

@seqArray = ("GCTCTG", "ATAGCATC", "GCTATCAG", "CCTAAG", "TATCGATCG");

foreach $sequence (@seqArray){
	print "The length of $sequence is " . length($sequence) . " nucleotides\n";
}
