#usr/bin/perl -w

print("Please enter a DNA sequence: ");
$seq = <STDIN>;
chomp($seq);
$seq = uc($seq);

@nucleotides = split("", $seq);
foreach $nuc (@nucleotides){
	if($nuc eq "A"){
		print("T");
	}
	elsif($nuc eq "T"){
		print("A");
	}
	elsif($nuc eq "C"){
		print("G");
	}
	elsif($nuc eq "G"){
		print("C");
	}
}
