#!/usr/bin/perl -w

@array = (1, 2, 3, 4, 5);
foreach (@array){
	print "$_\n";
}
