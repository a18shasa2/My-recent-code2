#!/usr/bin/perl -w

if(1 < 5){
	print "1 is less than 5.";
}
