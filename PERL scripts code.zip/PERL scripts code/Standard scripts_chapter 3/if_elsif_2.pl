#!/usr/bin/perl -w

$scalarVar = 2;
if($scalarVar == 1){
	print "$scalarVar is equal to 1.";
}
elsif($scalarVar == 2){
	print "$scalarVar is equal to 2.";
}
elsif($scalarVar > 1){
	print "$scalarVar is greater than 1.";
}
