#!/usr/bin/perl -w

sub smallFunc{
   my $number = 5;
   print "This is the value of smallFunc's local \$number: $number.\n"
}

$number = 10;
print "This is the value of the global \$number variable: $number.\n";
smallFunc();
if(1){
   my $number = 3;
   print "This is another local \$number variable: $number.\n";
}
print "The global \$number variable is still $number.\n";

