#!/usr/bin/perl -w

sub smallFunction{
	print "The flow of execution jumps here when smallFunction is called.\n";
}

print "This is where execution starts.\n";
smallFunction();
print "This is executed when the body of smallFunction is finished.\n";
