#!/usr/bin/perl -w

use strict;

sub calculateSum{
my $value1 = $_[0];
my $value2 = $_[1];
my $sum = $value1 + $value2;
print "The sum is $sum.\n";
} 
calculateSum(4, 9);
