#!/usr/bin/perl -w

$scalarVar = 7;
if($scalarVar < 4){
	print "$scalarVar is less than 4.";
}
elsif($scalarVar > 6){
	print "$scalarVar is greater than 6.";
}
