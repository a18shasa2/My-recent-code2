#!/usr/bin/perl -w

print "Enter a number: ";
chomp($scalarVar = <STDIN>);
if($scalarVar > 3){
print "$scalarVar is greater than 3.";
}
