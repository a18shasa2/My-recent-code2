#!/usr/bin/perl -w

use strict;

sub reverseSign{
	my $number = $_[0];
	$number = -$number;
	return $number;
}

my $argNumber = 10;
$argNumber = reverseSign($argNumber);
print($argNumber);
