#!usr/bin/perl -w

print "Enter sequence 1: ";
$DNA1 = <STDIN>;
chomp($DNA1);

print "Enter sequence 2: ";
$DNA2 = <STDIN>;
chomp($DNA2);

$len1 = length($DNA1);
$len2 = length($DNA2);

if($len1 > $len2){
	print "The first sequence is longer\n";
}
elsif($len2 > $len1){
	print "The second sequence is longer\n";
}
else{
	print "The sequences have the same length\n";
}
