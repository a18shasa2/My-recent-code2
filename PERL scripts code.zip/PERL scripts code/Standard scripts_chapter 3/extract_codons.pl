#!usr/bin/perl -w

$DNAseq = "GAGCTAGGCATGACCAGCATTCAGGCATCC";

for($nuc = 0; $nuc < length($DNAseq) / 3; $nuc++){
	$subseq = substr($DNAseq, $nuc * 3, 3);
	print "Codon $nuc: $subseq\n";
}
