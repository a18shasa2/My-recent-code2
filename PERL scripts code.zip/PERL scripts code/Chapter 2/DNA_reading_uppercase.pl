#uc for upper_case letters. lc for lower-case letters. First three 1-3.
print "Write the DNA-sequence.\n";
$input1 = <STDIN>;
chomp($input1);
$input1_capital=uc($input1);
print "Your DNA-sequence is: $input1_capital\n";