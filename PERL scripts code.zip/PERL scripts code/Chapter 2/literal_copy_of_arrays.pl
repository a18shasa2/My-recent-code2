#!/usr/bin/perl �w 
print("****************\n*", '@hotmail', "*\n**************** \n"); 
#Write /n top add a new line to pasted text.