#uc for upper_case letters. lc for lower-case letters. First three 0-3 (since starts counting from 0)
print "Write the DNA-sequence.\n";
$input1 = <STDIN>;
chomp($input1);
$input1_capital=uc($input1);
$input1_capital_first_three = substr($input1_capital, 0, 3);
print "Your DNA-sequence is: $input1_capital_first_three\n";