print("Write your name and press enter.\n"); 
$input = <STDIN>;
chomp($input);
print "Your name is $input.\n";