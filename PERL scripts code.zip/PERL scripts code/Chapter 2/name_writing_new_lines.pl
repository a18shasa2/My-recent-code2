print("Write your first name and press enter.\n"); 
$input1 = <STDIN>;
chomp($input1);
print("Write your second name and press enter.\n"); 
$input2 = <STDIN>;
chomp($input2);
print "Your name is $input1\n$input2.\n";