#First input. Second arrow. Third print arrays. 
print "Write the first accession number.\n";
$input1 = <STDIN>;
chomp($input1);
print "Write the second accession number.\n";
$input2 = <STDIN>;
chomp($input2);
print "Write the third accession number.\n";
$input3 = <STDIN>;
chomp($input3);
@protein_accession_number = ("$input1", "$input2", "$input3");
@reverse_protein_accession_number = reverse(@protein_accession_number);
print "Your accession number at index 2, 1 and 0 are:@reverse_protein_accession_number\n"