#First input. Second arrow. Third print arrays. 
print "Write the first accession number.\n";
$input1 = <STDIN>;
chomp($input1);
print "Write the second accession number.\n";
$input2 = <STDIN>;
chomp($input2);
print "Write the third accession number.\n";
$input3 = <STDIN>;
chomp($input3);
@protein_accession_number = ("$input1", "$input2", "$input3");
print "Your acscession number at index 0 is: $protein_accession_number[0]\n";