#Zero print "make visible on screen". First input "user writes variable". Second concatenation "fuse two variables into one".  
print("Write person #1s name and press enter.\n"); 
$input1 = <STDIN>;
chomp($input1);
print("Write person #2s name and press enter.\n"); 
$input2 = <STDIN>;
chomp($input2);
$part1 = $input1;
$part2 = $input2;
$string = $part1 . $part2;
print "Your names are combined to form $string.\n";