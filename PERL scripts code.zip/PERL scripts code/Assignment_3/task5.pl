#!/usr/bin/perl
$ARGV[0];
$input1=$ARGV[0];
@array1=();
my @array1;
@array2=();
my @array2;
push(@array1, $input1);
@input1_split = split("", $array1[0]);
#A regular expression is used to check if the entered DNA-sequence is valid. If the DNA-sequence only contains upper-case or lower-case letters, the DNA-sequence is valid. If not, an error message will appear stating that illegal characters are present in the DNA-sequence.
if($input1 =~ /^[AaTtGgCc]+$/){     
} 
elsif($input1 !=~ /^[AaTtGgCc]+$/){     
die "This sequence contains illegal characters\n";
} 
#Below is another way of checking whether a DNA-sequence is valid. 
$var3=0;
$total=scalar(@input1_split);
while ($var3 < $total) {
if ($input1_split[$var3] eq "A"){
}
elsif ($input1_split[$var3] eq "a"){
}
elsif ($input1_split[$var3] eq "C"){
}
elsif ($input1_split[$var3] eq "c"){
}
elsif ($input1_split[$var3] eq "G"){
}
elsif ($input1_split[$var3] eq "g"){
}
elsif ($input1_split[$var3] eq "t"){
}
elsif ($input1_split[$var3] eq "T"){
}
else {
die "This sequence contains illegal characters\n";
}
$var3++;
}
#If the codons ATG or TAG are present, their respective sentences will be printed. 
$num_start_1=0;
$num_start_2=1;
$num_start_3=2;
$num_end_1=$total-3;
$num_end_2=$total-2;
$num_end_3=$total-1;
$part1_start = $input1_split[$num_start_1];
$part2_start = $input1_split[$num_start_2];
$part3_start = $input1_split[$num_start_3];
$codon_start= $part1_start . $part2_start . $part3_start;
$part1_end = $input1_split[$num_end_1];
$part2_end = $input1_split[$num_end_2];
$part3_end = $input1_split[$num_end_3];
$codon_end = $part1_end . $part2_end . $part3_end;

if ($codon_start eq "ATG"){
print "Begins with start codon\n";
}
elsif($codon_start ne "ATG"){
}
if ($codon_end eq "TAG"){
print "Ends with end codon\n";
}
elsif($codon_end ne "TAG"){
}
#As long as the codon is NOT ATG or TAG, the codon will be treated as a ORF and stored into an array and then printed. In addition, the number of start-codons, ATGs, are counted. 
$length=length($input1);
$var1=0;
$var2=0;
while ($var1 < $length) {
$triplet1 = substr($input1, $var1, 3);
if ($triplet1 eq "ATG") {
}
elsif ($triplet1 eq "TAG") {
}
else {
push(@array2, $triplet1);
}
if ($triplet1 eq "ATG") {
$var2++;
}
elsif ($triplet1 ne "ATG") {
}
$var1++;
$var1++;
$var1++;
}
shift(@array2);
print "Contains ORF: @array2\n";
print "Are $var2 start-codons \n";