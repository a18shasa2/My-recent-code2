#!/usr/bin/perl
$ARGV[0];
@array1=();
my @array1;
@array2=();
my @array2;
@array21=();
my @array21;
@array3=();
my @array3;
#A file handle is opened and the first two lines are read. 
open(TEXTFILE, "<$ARGV[0].txt");
$add1=0;
$add2=0;
$add11=0;
while ($add1 < 2){
	$line = <TEXTFILE>;
	push(@array1, $line);
	push(@array2, $line);
	@array1_splitted = split("", $array1[0]);
	shift(@array1_splitted);
        shift(@array1_splitted);
        shift(@array1_splitted);
        shift(@array1_splitted);
while ($add2 < 1){
$accession_number= $array1_splitted[0] . $array1_splitted[1] . $array1_splitted[2] . $array1_splitted[3] . $array1_splitted[4] . $array1_splitted[5];
print "$ARGV[0] has accession number $accession_number\n";
#A regulator expression is used to determine whether the text-file is a Swissprot or TREMBL entry. 
foreach $array2 (@array2){
	if($array2 =~ />sp/){
		print "This is a Swissprot entry\n";
	}
	elsif($array2 =~ />tr/){
		print "This is a TREMBL entry\n";
	}
}
$add2++;
}
#A regular expression is used to detect the element in the array beginning with OS and then print all other characters in that element.
@array21=split(" ", $array2[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /OS/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
push(@array3_split_join, $array21[$add4]);
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
$add3++;
}
}

print "Organism: @array3_split_join\n";
	}
}
#A regular expression is used to detect the element in the array beginning with GN and then print all other characters in that element.
while ($add11 < 1){
foreach $array21 (@array21){
	if($array21 =~ /GN/){
push(@array4, $array21);
@array4_split=split("", $array4[0]);
shift(@array4_split);
shift(@array4_split);
shift(@array4_split);
@array4_split_join = join("", @array4_split);
print "Gene name: @array4_split_join\n";
	}
}
$add11++;
}
#A regulator expression is used to determine what type of evidence is indicated based on that PE-value. 
foreach $array21 (@array21){
	if($array21 =~ /PE=1/){
		print "Evidence: Experimental evidence at protein level\n";
	}
	elsif($array21 =~ /PE=2/){
		print "Evidence: Experimental evidence at transcript level\n";
	}
	elsif($array21 =~ /PE=3/){
		print "Evidence: Experimental evidence inferred from homologyl\n";
	}
	elsif($array21 =~ /PE=4/){
		print "Evidence: Experimental evidence is predicted\n";
	}
	elsif($array21 =~ /PE=5/){
		print "Evidence: Experimental evidence is uncertain\n";
	}
}
undef @array21;
$add1++;	
}
close TEXTFILE;