#!/usr/bin/perl

#Note: The program will work correctly as long as the tagged lines have "exon" beginning of each desired line. If not, there is something wrong with the txt-file.
#The file handle is opened and the total number of lines in the text-file is counted.
open(TEXTFILE1, "<NM_000071.txt");
$nr_of_lines = 0;
while (<TEXTFILE1>) { 
	$nr_of_lines++;
}
close TEXTFILE1;

@array1=();
my @array1;
@array2=();
my @array2;
@array21=();
my @array21;
@array3=();
my @array3;
#A new file handle is opened and lines are read. 
open(TEXTFILE, "<NM_000071.txt");
$add1=0;
$add2=0;
$add11=0;
$count1=0;
while ($add1 < $nr_of_lines){
	$line = <TEXTFILE>;
	push(@array2, $line);
#A regular expression is used to detect the element in the array that has VERSION and then print the element next to it.
$val1=0;
@array21=split(" ", $array2[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /VERSION/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
while ($val1 < 1){
print "Version number: $array21[$add4]\n";
$val1++;
}
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
#A regular expression is used to detect the element in the array that has SOURCE and then print the element next to it.
@array21=split(" ", $array2[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /SOURCE/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$add4=$add3+1;
$add5=$add3+2;
$add6=$add3+3;
while ($val1 < 1){
print "Source organism: $array21[$add4] $array21[$add5] $array21[$add6]\n";
$val1++;
}
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
#A regular expression is used to detect the element in the array that has FEATURES. This is important in order to detect the tagged lines.
@array21=split(" ", $array2[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /FEATURES/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$count2=$add1;
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}


	}
}
#This regular expression below is superflous. Ignore it.
@array21=split(" ", $array2[$add1]);
foreach $array21 (@array21){
	if($array21 =~ /exon/){
push(@array3, $array21);
@array3_split=split("", $array3[0]);
shift(@array3_split);
shift(@array3_split);
shift(@array3_split);
@array3_split_join = join("", @array3_split);

$total=scalar(@array21);
$add3=0;
while ($add3 < $total){
if ($array21[$add3] eq $array3[0]){
$count1++;
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
elsif ($array21[$add3] ne $array3[0]){
undef @array21;
undef @array3;
undef @array3_split;
undef @array3_split_join;
$add3++;
}
}

	}
}
undef @array21;
$add1++;	
}
#The file handle is closed.
close TEXTFILE;

#A new file handle is opened and lines are read in order to start at the beginning.
open(TEXTFILE2, "<NM_000071.txt");
#All lines until FEATURES are skipped.
$skip=0;
while ($skip < $count2){
<TEXTFILE2>;
$skip++;
}
#The exons are counted below. 
$skip2=0;
$count3=0;
$final=$nr_of_lines-$count2-3;
while ($skip2 < $nr_of_lines){
	$line2 = <TEXTFILE2>;
	push(@array31, $line2);
	@array31_splitted = split(" ", $array31[0]);
if ($array31_splitted[0] eq "exon"){
$count3++;
$skip2++;
undef @array31_splitted;
undef @array31;
}
elsif ($array31_splitted[0] ne "exon"){
$skip2++;
undef @array31_splitted;
undef @array31;
}
}
print "$count3 exons\n";
#The file handle is closed.
close TEXTFILE2;