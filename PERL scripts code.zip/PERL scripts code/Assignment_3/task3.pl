#!/usr/bin/perl
$ARGV[0]; $ARGV[1]; $ARGV[2];
$input1=$ARGV[0];
$input2=$ARGV[1];
$input3=$ARGV[2];
@array1=();
my @array1;
@array2=();
my @array2;
@array3=();
my @array3;
@array4=();
my @array4;
#Using the variable from the second argument, the designated text-file is read using a file handle and stored in an array. The number of elements in the array is counted. 
open(TEXTFILE, "$input2");
$total = 0;
while (<TEXTFILE>) { 
	$total++
}
$num1=0;
$num2=0;
#The filehandle is closed. 
close TEXTFILE;
#As long as the $num1 is below $total, each element in array1 will be read individually and processed.
while ($num1 < $total)  {
open(ENTRYFILE, "<$array1[$num1].txt");

$R = 0;
while ($R < 1) { 
<ENTRYFILE>;
	$R++;
}

while (<ENTRYFILE>){
	@array2 = <ENTRYFILE>;
    @array3 = <ENTRYFILE>;	
}
#@array2_join=join("",@array2);
$seq=@array2;
$seq_length=length($seq);
#If the length of the sequence is greater than or equal to the value inputted in the first argument and if the word append is inputted in the third argument, the ManySeqs.fasta will be appended and the entire sequence will be written to ManySeqs.fasta.
if ($seq_length > $input1){
if ($input3 eq "append"){
open(WRITEHANDLE, ">>ManySeqs.fasta");
}
elsif ($input3 ne "append"){
open(WRITEHANDLE, ">ManySeqs.fasta");
}
print(WRITEHANDLE @array3);
#The write handle is closed. 
close(WRITEHANDLE);  
close ENTRYFILE;
push(@array4,"E");
print "$array1[$num1] length $seq_length added\n";
$num1++;
}
elsif ($seq_length < $input1){
close ENTRYFILE;
print "$array1[$num1] length $seq_length too short\n";
my @array2;
my @array3;
$num1++;
}
}
$count1=scalar(@array4);
print "$count1 sequences written to ManySeqs.fasta\n";