#!/usr/bin/perl

use warnings;

if(-r "newFolder/testFile.txt"){
	print("The file testFile.txt exists in newFolder and is readable.\n");
}
