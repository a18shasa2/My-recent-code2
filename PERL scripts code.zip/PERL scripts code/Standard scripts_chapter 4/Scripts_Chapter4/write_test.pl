#!/usr/bin/perl

use warnings;

if(-w "newFile.txt"){
	print("The file newFile.txt exists in the current folder and is writable.\n");
}
