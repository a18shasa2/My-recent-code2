#!/usr/bin/perl

use warnings;

if(!open(WRITE_HANDLE, ">newFile.txt")){
	die "Could not open newFile.txt for writing";
}
print(WRITE_HANDLE "This string is printed to newFile.txt");
close(WRITE_HANDLE);
