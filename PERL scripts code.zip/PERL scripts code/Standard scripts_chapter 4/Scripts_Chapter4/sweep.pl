#!/usr/bin/perl

use warnings;

if(!open(MY_HANDLE, "testFile.txt")){
	die "Could not open testFile.txt";
}
@fileContent = <MY_HANDLE>;
print(@fileContent);
close(MY_HANDLE);
