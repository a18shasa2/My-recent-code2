#!/usr/bin/perl

use warnings;

if(!open(MY_HANDLE, "newFolder/testFile.txt")){
	die "Could not open testFile.txt";
}
while($fileLine = <MY_HANDLE>){
	print($fileLine);
}
close(MY_HANDLE);
