#!/usr/bin/perl

use warnings;

if(!open(BLAST, "blast_result.txt")){
	die "Could not open BLAST result file";
}	
@result = <BLAST>;
close(BLAST);
foreach $row (@result){
	@columns = split(/\t/, $row);
	if(scalar(@columns) > 1){
		if($columns[2] > 90){
			print("Identity: $columns[2]\n");
}
}
}
