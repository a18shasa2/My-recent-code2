#!/usr/bin/perl

use warnings;

if(!open(WRITE_HANDLE, ">newFile.txt")){
	die "Could not open to newFile.txt for writing";
}
@fileContent = ("Line 1\n", "Line 2\n", "Line 3\n");
print(WRITE_HANDLE @fileContent);
close(WRITE_HANDLE);
