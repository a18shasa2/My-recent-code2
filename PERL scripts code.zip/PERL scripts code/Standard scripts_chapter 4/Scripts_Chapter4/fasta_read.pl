#!/usr/bin/perl

use warnings;

if(!open(FASTA, "1AMA_A.fasta")){
	die "Could not open FASTA file";
}
@content = <FASTA>;
shift(@content);
print(@content);
close(FASTA);
