#!/usr/bin/perl

use warnings;

#Print the result of a multiplication
$product = 3 * 7;
print("Product: $product\n");

#Division has higher precedence than subtraction
$result = 6 - 4 / 2;
print("Result: $result\n");

#The ** operator raises the left number to the power of the right number
$power = 3 ** 4;
print("Power: $power\n");

#The modulo operator calcualtes the remainder of division 
$remainder = 7 % 2;
print("Remainder: $remainder\n");






















