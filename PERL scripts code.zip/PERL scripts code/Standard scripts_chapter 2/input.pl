#!/usr/bin/perl -w

#Ask the user for input
print "Please enter a string: ";
$input = <STDIN>;
chomp($input);
print "You typed $input!\n";






























