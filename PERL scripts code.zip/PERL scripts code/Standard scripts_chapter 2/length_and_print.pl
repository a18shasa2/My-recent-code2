#!/usr/bin/perl

use warnings;

#Get the number of nucleotides in a DNA sequence
$DNA = "CGTATCATCTGCATGC";
$nucleotides = length($DNA);
print("Number of nucleotides: $nucleotides\n");

#Remove the last newline
$greeting = "Hello World\n";
chomp($greeting);
print "$greeting $greeting";


























