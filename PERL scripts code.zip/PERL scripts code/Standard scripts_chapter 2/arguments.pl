#!/usr/bin/perl

#Get program arguments from @ARGV
$num1 = $ARGV[0];
$num2 = $ARGV[1];

print("The sum of the arguments is ", $num1 + $num2, "\n");




























