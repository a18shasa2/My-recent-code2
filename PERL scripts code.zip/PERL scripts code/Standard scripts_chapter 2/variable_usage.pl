#!/usr/bin/perl

use warnings;

# Perl converts strings to numbers
# and prints warning messages.

#Conversion to 2
$result = 4 * "2abc" - 3;
print("Result: $result\n");

#Conversion to 0
$result = 4 * "ab72cd" - 3;
print("Result: $result\n");

