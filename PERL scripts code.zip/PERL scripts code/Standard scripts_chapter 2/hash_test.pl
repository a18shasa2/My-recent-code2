#!/usr/bin/perl

use warnings;

#Create a hash
%person = ("Organism" => "Human", "Length" => 187, "Name" => "John");

#Extract the value of key "Name"
print("Name: $person{'Name'}\n");

#Change value of key "Length"
$person{"Length"} = 170;

#Add new key
$person{"Age"} = 30;

#Remove all keys/values from the hash
%person = ();































