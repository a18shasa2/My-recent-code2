#!/usr/bin/perl

#Default precedence
$result = 3 + 8 * 2;
print "Result: $result\n";

#Using parentheses
$result = (3 + 8) * 2;
print "Result: $result\n";























