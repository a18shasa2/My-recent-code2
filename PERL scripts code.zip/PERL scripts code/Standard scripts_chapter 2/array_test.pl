#!/usr/bin/pe#!/usr/bin/perl

use warnings;

#Create an array
@organism = ("Human", "Rat", "Cat", "Yeast");

#Extract the second element
print("Element at index 1: $organism[1]\n");

#Change the third element
$organism[2] = "Chicken";
print("@organism\n");

#Extract more than one element
print("Elements at index 0 and 3: @organism[0,3]\n");

#Remove all elements from the array
@organism = ();




























