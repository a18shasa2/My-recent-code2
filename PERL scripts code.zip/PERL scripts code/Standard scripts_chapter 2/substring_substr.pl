#!/usr/bin/perl -w

$DNA = "TATCCACAGATCTCTGAGTC";

#Extract a DNA segment
$segment = substr($DNA, 3, 5);
print "Nucleotides 4 to 8: $segment\n";

#Introduce mutations
substr($DNA, 2, 6, "GGGGGG");
print "Sequence: $DNA\n";



























