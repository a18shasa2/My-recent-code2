#!/usr/bin/perl

#Increment placed operator after $var1
$var1 = 3;
$var2 = $var1++;
print("Var1: $var1 Var2: $var2\n");

#Increment placed operator before $var1
$var1 = 3;
$var2 = ++$var1;
print("Var1: $var1 Var2: $var2\n");

























