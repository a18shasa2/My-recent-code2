#!/usr/bin/perl

#Assigning an array to a scalar variable
@organism = ("Human", "Rat", "Cat", "Yeast");
$size = @organism;
print("Number of elements: $size\n");

#List context can also be indicated by parentheses
($a, $b) = (10, 20);
print "$a $b\n";





























