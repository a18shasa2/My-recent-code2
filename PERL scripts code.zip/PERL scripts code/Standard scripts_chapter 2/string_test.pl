#!/usr/bin/perl

use warnings;

#Printing strings without newline between them
print "First print";
print "Second print\n";

#Interpolation occurs in double quoted strings
$number = 16;
print "This script has $number lines\n";

#Using backslash
print "The value of \$number is $number\n";

#This is how single quoted strings behave
print 'This script has $number lines\n';



















