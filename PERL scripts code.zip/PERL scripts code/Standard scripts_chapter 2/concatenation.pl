#!/usr/bin/perl

use warnings;

$part1 = "Hello ";
$part2 = "world!\n";
$string = $part1 . $part2;
print($string);




















