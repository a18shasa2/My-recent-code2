#uc for upper_case letters. lc for lower-case letters. First three 1-3.
print "What is the first number?\n";
$input1 = <STDIN>;
chomp($input1);
print "What is the second number?\n";
$input2 = <STDIN>;
chomp($input2);
if($input1 == $input2){
$sum = $input1 + $input2;
print "The sum of the two numbers is $sum \n";
}
elsif($input1 > $input2){ 
print "The highest value is $input1.";
}
elsif($input1 < $input2){ 
print "The highest value is $input2.";
}
