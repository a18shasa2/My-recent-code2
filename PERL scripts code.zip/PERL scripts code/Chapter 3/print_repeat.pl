sub example{
	$number1 = $_[0];
for($loopVar = 0; $loopVar < $number1; $loopVar++){
print "hello world\n";
} 
}



$num1 = $ARGV[0]; #argument

example($num1); #come AFTER argument and AFTER function

#save return means "return()"