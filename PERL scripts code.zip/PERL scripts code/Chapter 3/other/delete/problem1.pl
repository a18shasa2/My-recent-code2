#!/usr/bin/perl -w

$scalarVar = 10;
if($scalarVar > 2 && $scalarVar < 8){
	print "$scalarVar is between 2 and 8.";
}
