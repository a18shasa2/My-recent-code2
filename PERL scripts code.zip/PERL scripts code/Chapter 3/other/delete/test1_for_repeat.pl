#!/usr/bin/perl -w
print "Write a number (less 3/larger 3)\n";
$input1 = <STDIN>;
chomp($input1);
print "You wrote the value $input1\n";
for($loopVar = $input1; $loopVar < 3;){
	print "Write a number (less 3/larger 3)\n";
$input1 = <STDIN>;
chomp($input1);
print "You wrote the value $input1\n";
}
print "You have reached the end of the program.\n";