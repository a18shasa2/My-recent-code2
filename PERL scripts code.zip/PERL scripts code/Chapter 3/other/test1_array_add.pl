#!/usr/bin/perl
print "Write one of the words: (hello/bye)\n";
$input1 = <STDIN>;
chomp($input1);
@array = ();
my @array;
push(@array, $input1);
print "You have entered $array[0]\n";
