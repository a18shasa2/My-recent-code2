#!/usr/bin/perl -w
print "Write number: (less 3/larger 3)\n";
$input1 = <STDIN>;
chomp($input1);
print "You wrote the value $input1\n";
$loopVar = $input1;
while($loopVar < 3){
	print "Write a number (less 3/larger 3)\n";
$input1 = <STDIN>;
chomp($input1);
print "You wrote the value $input1\n";
$loopVar = $input1;
}
print "You have reached the end of the program.\n";