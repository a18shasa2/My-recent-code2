#!/usr/bin/perl -w
print "Write one of the words: (hello/bye)\n";
$input1 = <STDIN>;
chomp($input1);
if($input1 eq "hello"){
	print "You wrote the word hello.\n";
	while($input1 eq "hello"){
print "Write one of the words: (hello/bye)\n";
$input2 = <STDIN>;
chomp($input2);
$loopVar++
}
}
elsif($input1 eq "bye"){
	print "You wrote the word bye.";
}