#uc for upper_case letters. lc for lower-case letters. First three 1-3.
my $name   = $ARGV[5];
my $number = $ARGV[3];
print "What is the first number?\n";
$input1 = <STDIN>;
chomp($input1);
print "What is the second number?\n";
$input2 = <STDIN>;
chomp($input2);
print "What is the arithmetic operator?\n";
$input3 = <STDIN>;
chomp($input3);
my $total;
if ($input3 eq "+"){
	$total = $input1 + $input2;

}
elsif($input3 eq "-"){
	$total = $input1 - $input2;
#print "The value is $total\n";
}
elsif($input3 eq "/"){
	$total = $input1 / $input2;
#print "The value is $total\n";
}
elsif($input3 eq "*"){
	$total = $input1 * $input2;
#print "The value is $total\n";
}
print "The value is $total\n";

sub example{
	$number1 = $_[0];
	$number2 = shift = $_[1];
	$total = $number1 - $number2
	print "The value is $total\n";
	
}
