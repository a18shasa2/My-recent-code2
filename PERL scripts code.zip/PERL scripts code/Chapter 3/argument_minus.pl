#argument for FUNCTIONS. 
sub example{
	$number1 = $_[0];
	$number2 = $_[1];
	$total = $number1 - $number2;
	
	return (abs($total));
}

$total2 = example(5, 6);

$total3 = $total2 * 5;

______________________________________________________
sub example{
	$number1 = $_[0];
for($loopVar = 0; $loopVar < $number1; $loopVar++){
print "hello world\n";
} 
}


______________________________________________________
print "The value is $total3\n";
#What is the difference between return and print? 
If negative value becomes positive value. 
How do I specify that? 

is it possible to make a exactly correct order in hash when retrieving keys? 
After this course, can you say that you have basic or advanced knowledge of Perl?
Can you use C++ or C# for bioinformatics too? So only Perl is really used? 
Python or R. 
Do you use Perl or Python. Main R. 

Thanks! I have a course now. 
